# 🔐 Módulo de Inicio de Sesión Deslizante - FINI UAGRM

Este paquete contiene el **componente de Inicio de Sesión / Registro deslizante (Dual Panel)** con la paleta de colores institucional de la **Facultad Integral de Ichilo (UAGRM)** y su imagen de fondo oficial.

---

## 🚀 Cómo ejecutar en desarrollo

1. Descomprime este archivo `.zip` en tu computadora.
2. Abre una terminal dentro de la carpeta descomprimida.
3. Instala las dependencias:
   ```bash
   npm install
   ```
4. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```
5. Abre en tu navegador [http://localhost:5173](http://localhost:5173)

---

## 📂 Estructura de archivos

```text
├── public/
│   ├── fondo-fini.jpg           # Imagen de fondo institucional
│   ├── logo-ichilo.png          # Logo oficial de la Facultad
│   └── escudo-universidad.png   # Escudo UAGRM
├── src/
│   ├── components/
│   │   ├── AuthPage.jsx         # Componente principal con animación sliding
│   │   └── AuthPage.css         # Estilos responsive, gradientes y animaciones
│   ├── services/
│   │   └── auth.js              # Funciones para consumir endpoints (Login / Register)
│   ├── App.jsx                  # Ejemplo de integración
│   ├── main.jsx                 # Entry point de React
│   └── index.css                # Reset CSS
├── index.html
├── package.json
└── vite.config.js
```

---

## 🛠️ Cómo reutilizarlo en otro proyecto React / Next.js / Vite

1. **Copiar componentes e imágenes:**
   - Copia `src/components/AuthPage.jsx` y `src/components/AuthPage.css` a la carpeta de componentes de tu nuevo proyecto.
   - Copia las imágenes de `public/` (`fondo-fini.jpg` y `logo-ichilo.png`) a la carpeta `public/` de tu nuevo proyecto.

2. **Importar y Usar:**
   ```jsx
   import AuthPage from './components/AuthPage';

   function App() {
     const handleLoginSuccess = (user) => {
       console.log('Usuario autenticado:', user);
     };

     return <AuthPage onLoginSuccess={handleLoginSuccess} />;
   }
   ```

3. **Configuración de API (Opcional):**
   - Configura la variable de entorno `VITE_API_URL` en tu archivo `.env`:
     ```env
     VITE_API_URL=http://tu-backend-api.com/api
     ```
