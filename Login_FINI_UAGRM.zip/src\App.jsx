import React, { useState } from 'react';
import AuthPage from './components/AuthPage';

function App() {
  const [user, setUser] = useState(null);

  const handleLoginSuccess = (userData) => {
    setUser(userData);
    alert(`¡Bienvenido ${userData?.nombre || userData?.username || 'al sistema'}!`);
  };

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <div style={{ minHeight: '100vh' }}>
      {!user ? (
        <AuthPage onLoginSuccess={handleLoginSuccess} />
      ) : (
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justify-content: 'center',
          minHeight: '100vh',
          color: 'white',
          background: '#0f172a',
          gap: '20px'
        }}>
          <h1>Sesión Iniciada Exitosamente</h1>
          <p>Usuario: <strong>{user.nombre || user.username}</strong> ({user.rol || 'Usuario'})</p>
          <button
            onClick={handleLogout}
            style={{
              padding: '12px 28px',
              background: '#b91c1c',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontWeight: 'bold',
              cursor: 'pointer'
            }}
          >
            Cerrar Sesión
          </button>
        </div>
      )}
    </div>
  );
}

export default App;
