import React, { useState } from 'react';
import { login, register } from '../services/auth';
import './AuthPage.css';

function AuthPage({ onLoginSuccess }) {
  const [isActive, setIsActive] = useState(false); // false = Sign In, true = Sign Up
  const [isLoading, setIsLoading] = useState(false);

  const [loginData, setLoginData] = useState({
    correo: '',
    password: ''
  });

  const [registerData, setRegisterData] = useState({
    nombre: '',
    tipoUsuario: 'interno',
    cargo: '',
    correo: '',
    password: '',
    confirmPassword: ''
  });

  const handleLoginChange = (e) => {
    setLoginData({
      ...loginData,
      [e.target.name]: e.target.value
    });
  };

  const handleRegisterChange = (e) => {
    setRegisterData({
      ...registerData,
      [e.target.name]: e.target.value
    });
  };

  const handleTipoUsuario = (tipo) => {
    setRegisterData({
      ...registerData,
      tipoUsuario: tipo
    });
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    if (!loginData.correo || !loginData.password) {
      alert('Por favor completa todos los campos');
      return;
    }

    try {
      setIsLoading(true);
      const response = await login(loginData.correo, loginData.password);
      onLoginSuccess(response.user);
    } catch (error) {
      console.error(error);
      alert(error.message || 'Error al iniciar sesión');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e) => {
    e.preventDefault();

    if (registerData.password !== registerData.confirmPassword) {
      alert('Las contraseñas no coinciden');
      return;
    }

    if (registerData.password.length < 6) {
      alert('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    setIsLoading(true);

    try {
      const payload = {
        username: registerData.correo,
        email: registerData.correo,
        password: registerData.password,
        rol: registerData.tipoUsuario,
        nombre: registerData.nombre,
        cargo: registerData.cargo
      };

      const response = await register(payload);
      alert(response.mensaje || 'Cuenta creada exitosamente. Ya puedes iniciar sesión.');
      setIsActive(false); // Cambiar a inicio de sesión
    } catch (error) {
      console.error(error);
      alert(error.message || 'Error al registrar usuario');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className={`auth-sliding-container ${isActive ? 'active' : ''}`} id="container">
        
        {/* FORMULARIO DE REGISTRO (Sign Up) */}
        <div className="form-container sign-up">
          <form className="auth-form" onSubmit={handleRegisterSubmit}>
            <div className="form-brand">
              <img src="/logo-ichilo.png?v=2" alt="Logo FINI" className="brand-logo" />
              <h2>Crear Cuenta</h2>
              <p className="brand-subtitle">Plataforma Digital de Gestión Documental</p>
            </div>

            <div className="form-scrollable">
              <div className="input-group">
                <label>Nombre Completo</label>
                <input
                  type="text"
                  name="nombre"
                  placeholder="Ej. Juan Pérez"
                  value={registerData.nombre}
                  onChange={handleRegisterChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>Tipo de Usuario</label>
                <div className="tipo-usuario-selector">
                  <button
                    type="button"
                    className={`user-type-pill ${registerData.tipoUsuario === 'interno' ? 'active' : ''}`}
                    onClick={() => handleTipoUsuario('interno')}
                  >
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                      <circle cx="9" cy="7" r="4" />
                      <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                    </svg>
                    Interno
                  </button>
                  <button
                    type="button"
                    className={`user-type-pill ${registerData.tipoUsuario === 'externo' ? 'active' : ''}`}
                    onClick={() => handleTipoUsuario('externo')}
                  >
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="10" />
                      <line x1="2" y1="12" x2="22" y2="12" />
                      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                    </svg>
                    Externo
                  </button>
                </div>
              </div>

              <div className="input-group">
                <label>Cargo / Función</label>
                <input
                  type="text"
                  name="cargo"
                  placeholder="Ej: Secretaria, Docente, Estudiante..."
                  value={registerData.cargo}
                  onChange={handleRegisterChange}
                  required
                />
              </div>

              <div className="input-group">
                <label>Correo Electrónico</label>
                <input
                  type="email"
                  name="correo"
                  placeholder="usuario@fini.uagrm.edu.bo"
                  value={registerData.correo}
                  onChange={handleRegisterChange}
                  required
                />
              </div>

              <div className="input-row">
                <div className="input-group">
                  <label>Contraseña</label>
                  <input
                    type="password"
                    name="password"
                    placeholder="••••••••"
                    value={registerData.password}
                    onChange={handleRegisterChange}
                    minLength="6"
                    required
                  />
                </div>
                <div className="input-group">
                  <label>Confirmar</label>
                  <input
                    type="password"
                    name="confirmPassword"
                    placeholder="••••••••"
                    value={registerData.confirmPassword}
                    onChange={handleRegisterChange}
                    required
                  />
                </div>
              </div>
            </div>

            <button type="submit" className="submit-btn" disabled={isLoading}>
              {isLoading ? 'Creando cuenta...' : 'Registrarse'}
            </button>

            <div className="mobile-toggle">
              <span>¿Ya tienes cuenta?</span>
              <button type="button" onClick={() => setIsActive(false)}>Iniciar Sesión</button>
            </div>
          </form>
        </div>

        {/* FORMULARIO DE INICIO DE SESIÓN (Sign In) */}
        <div className="form-container sign-in">
          <form className="auth-form" onSubmit={handleLoginSubmit}>
            <div className="form-brand">
              <img src="/logo-ichilo.png?v=2" alt="Logo FINI" className="brand-logo" />
              <h2>Sistema de Documentos</h2>
              <p className="brand-subtitle">Facultad Integral de Ichilo - UAGRM</p>
            </div>

            <div className="input-group">
              <label>Correo Electrónico o Usuario</label>
              <div className="input-with-icon">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                <input
                  type="text"
                  name="correo"
                  placeholder="admin o tu@email.com"
                  value={loginData.correo}
                  onChange={handleLoginChange}
                  required
                />
              </div>
            </div>

            <div className="input-group">
              <label>Contraseña</label>
              <div className="input-with-icon">
                <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
                <input
                  type="password"
                  name="password"
                  placeholder="••••••••"
                  value={loginData.password}
                  onChange={handleLoginChange}
                  required
                />
              </div>
            </div>

            <div className="forgot-password">
              <a href="#forgot" onClick={(e) => { e.preventDefault(); alert('Por favor contacta al administrador del sistema para restablecer tu clave.'); }}>
                ¿Olvidaste tu contraseña?
              </a>
            </div>

            <button type="submit" className="submit-btn" disabled={isLoading}>
              {isLoading ? 'Iniciando Sesión...' : 'Iniciar Sesión'}
            </button>

            <div className="mobile-toggle">
              <span>¿No tienes una cuenta?</span>
              <button type="button" onClick={() => setIsActive(true)}>Registrarse</button>
            </div>
          </form>
        </div>

        {/* CONTENEDOR DESLIZANTE DE TRANSICIÓN */}
        <div className="toggle-container">
          <div className="toggle">
            
            {/* PANEL IZQUIERDO (Se muestra cuando está en la pantalla de Registro para volver a Iniciar Sesión) */}
            <div className="toggle-panel toggle-left">
              <div className="toggle-icon-badge">
                <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
                  <polyline points="10 17 15 12 10 7" />
                  <line x1="15" y1="12" x2="3" y2="12" />
                </svg>
              </div>
              <h1>¡Bienvenido de Nuevo!</h1>
              <p>
                Si ya posees un usuario registrado en el Sistema de Gestión Documental FINI, ingresa tus credenciales para continuar.
              </p>
              <button className="toggle-action-btn" id="login" onClick={() => setIsActive(false)}>
                Iniciar Sesión
              </button>
            </div>

            {/* PANEL DERECHO (Se muestra cuando está en la pantalla de Inicio de Sesión para ir a Registro) */}
            <div className="toggle-panel toggle-right">
              <div className="toggle-icon-badge">
                <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" strokeWidth="1.8">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <line x1="19" y1="8" x2="19" y2="14" />
                  <line x1="16" y1="11" x2="22" y2="11" />
                </svg>
              </div>
              <h1>¡Hola, Bienvenido!</h1>
              <p>
                Regístrate con tus datos para acceder al seguimiento y radicación de documentos de la Facultad Integral de Ichilo.
              </p>
              <button className="toggle-action-btn" id="register" onClick={() => setIsActive(true)}>
                Registrarse
              </button>
            </div>

          </div>
        </div>

      </div>

      {/* Pie de Página Institucional */}
      <footer className="auth-footer-bottom">
        <p>© 2026 Universidad Autónoma Gabriel René Moreno — Facultad Integral de Ichilo</p>
      </footer>
    </div>
  );
}

export default AuthPage;